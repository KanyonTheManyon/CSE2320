// Dalio, Brian A.
// abc1234
// 2018 July 28
//--------#---------#---------#---------#--------#
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "support.h"

//--------#---------#---------#---------#--------#
int main( int argc, char *argv[] ) {
  int n;
  int ascending;
  int descending;
  int shuffle;
  int *A;

  // Enable thousand separators in printf().
  setlocale( LC_NUMERIC, "" );

  // Initialize the pseudorandom number generator.
  srand48( time( NULL ) );

  // Announce ourselves.
  printf( "=== Insertion Sort ===\n" );

  // Get how many items to sort, and whether we should
  // do an ascending test, a descending test, and/or
  // a shuffle test.
  getArgs( argc, argv, &n, &ascending, &descending, &shuffle );

  // Allocate the array.
  A = malloc( sizeof( int ) * n );
  if ( NULL == A ) {
    printf( "%s: unable to allocate %d-element array.\n", argv[0], n );
  }
  printf( "%'d item%s in array.\n", n, n == 1 ? "" : "s" );

  //------------------------------------------------
  // Do the ascending test, if requested.
  for ( int i=0; i < ascending; i++ ) {
    printf( "--- Ascending test %d of %d\n", i+1, ascending );

    fillArray( A, n, ASCENDING );
    insertionTest( A, n, ASCENDING );
    checkArray( A, n );
  }

  //------------------------------------------------
  // Do the descending test, if requested.
  for ( int i=0; i < descending; i++ ) {
    printf( "--- Descending test %d of %d\n", i+1, descending );

    fillArray( A, n, DESCENDING );
    insertionTest( A, n, DESCENDING );
    checkArray( A, n );
  }

  //------------------------------------------------
  // Do the shuffle test, if requested.
  for ( int i=0; i < shuffle; i++ ) {
    printf( "--- Shuffle test %d of %d\n", i+1, shuffle );

    fillArray( A, n, SHUFFLE );
    insertionTest( A, n, SHUFFLE );
    checkArray( A, n );
  }

  // All done!  Free the allocated array.
  free( A );
}

//--------#---------#---------#---------#--------#
