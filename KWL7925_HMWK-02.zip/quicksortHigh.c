// Loyd, Kanyon Warner
// KWL7925
// 2018 July 30
//--------#---------#---------#---------#--------#
#include <stdio.h>
#include <time.h>

#include "support.h"

//--------#---------#---------#---------#--------#
static int partitionHigh( int *A, int low, int high )
{
    int pivot, i, j, temp;
    pivot = A[high];
    i=low-1;
    for(j=low; j<=high-1; j++){
        if(A[j]<=pivot){
            i++;
            temp=A[j];
            A[j]=A[i];
            A[i]=temp;
        }
    }
    temp=A[i+1];
    A[i+1]=A[high];
    A[high]=temp;
    return i+1;
}

//--------#---------#---------#---------#--------#
static void quicksortHigh( int *A, int low, int high )
{
    int p;
    if(low<high){
        p=partitionHigh(A, low, high);
        quicksortHigh(A, low, p-1);
        quicksortHigh(A,p+1, high);
    }
}

//--------#---------#---------#---------#--------#
void quicksortHighTest( int *A, int n, int order )
{
  clock_t begin;
  clock_t end;
  double  elapsed;

  begin = clock();
  quicksortHigh( A, 0, n-1 );
  end = clock();

  elapsed = (double) ( end - begin ) / CLOCKS_PER_SEC;
  printf( "%.3fs to quicksort (high) %s array.\n", elapsed, ORDER_STR( order ) );
}

//--------#---------#---------#---------#--------#
