// Loyd, Kanyon Warner
// KWL7925
// 2018 July 30
//--------#---------#---------#---------#--------#
#include <stdio.h>
#include <time.h>

#include "support.h"

//--------#---------#---------#---------#--------#
static int partitionMedian( int *A, int low, int high )
{
    int pivot, i, j, temp, median, mid=(high+low)/2;
    if(A[mid]<A[low]){
        temp=A[low];
        A[low]=A[mid];
        A[mid]=temp;
    }
    if(A[high] < A[low]){
        temp=A[low];
        A[low]=A[high];
        A[high]=temp;
    }
    if(A[mid]<A[high]){
        temp=A[mid];
        A[mid]=A[high];
        A[high]=temp;
    }
    pivot = A[high];
    i=low-1;
    for(j=low; j<=high-1; j++){
        if(A[j]<=pivot){
            i++;
            temp=A[j];
            A[j]=A[i];
            A[i]=temp;
        }
    }
    temp=A[i+1];
    A[i+1]=A[high];
    A[high]=temp;
    return i+1;
}

//--------#---------#---------#---------#--------#
static void quicksortMedian( int *A, int low, int high )
{
  int p;
    if(low<high){
        p=partitionMedian(A, low, high);
        quicksortMedian(A, low, p-1);
        quicksortMedian(A,p+1, high);
    }
}

//--------#---------#---------#---------#--------#
void quicksortMedianTest( int *A, int n, int order )
{
  clock_t begin;
  clock_t end;
  double  elapsed;

  begin = clock();
  quicksortMedian( A, 0, n-1 );
  end = clock();

  elapsed = (double) ( end - begin ) / CLOCKS_PER_SEC;
  printf( "%.3fs to quicksort (median) %s array.\n", elapsed, ORDER_STR( order ) );
}

//--------#---------#---------#---------#--------#
