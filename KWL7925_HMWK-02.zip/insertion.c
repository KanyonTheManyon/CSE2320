// Loyd, Kanyon Warner
// KWL7925
// 2018 July 30
//--------#---------#---------#---------#--------#
#include <stdio.h>
#include <time.h>

#include "support.h"

//--------#---------#---------#---------#--------#
static void insertion( int *A, int size )
{
  int key, j, i;
  for(j=1; j<size; j++){
    key=A[j];
    i=j-1;
    while(j>=0&&A[i]>key){
        A[i+1]=A[i];
        i--;
    }
    A[i+1]=key;
  }
}

//--------#---------#---------#---------#--------#
void insertionTest( int *A, int size, int order )
{
  clock_t begin;
  clock_t end;
  double  elapsed;

  begin = clock();
  insertion( A, size );
  end = clock();

  elapsed = (double) ( end - begin ) / CLOCKS_PER_SEC;
  printf( "%.3fs to insertion sort %s array.\n", elapsed, ORDER_STR( order ) );
}

//--------#---------#---------#---------#--------#
